 
<a href='<?php echo 
base_url("User/reportShop")."?shopId=".$shopId;
?>'> 
<button  class='btn btn-success float-right' type="button"> 
    Report this shop
</button>
</a>
